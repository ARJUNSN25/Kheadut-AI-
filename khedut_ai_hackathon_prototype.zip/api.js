/**
 * Khedut AI - Frontend API Client Bridge
 * Connects the mobile HTML/JS application directly to the Node.js/Express Backend API.
 */

const API_BASE_URL = 'http://localhost:5000/api/v1';

class KhedutApiClient {
  /**
   * Health Check
   */
  static async checkHealth() {
    const res = await fetch(`${API_BASE_URL}/health`);
    return await res.json();
  }

  /**
   * 1. Diagnose Leaf Image
   * @param {File|Blob} imageFile 
   * @param {string} crop (Tomato | Cotton | Chilli | etc.)
   */
  static async diagnoseLeaf(imageFile, crop = 'Tomato') {
    const formData = new FormData();
    formData.append('leafImage', imageFile);
    formData.append('crop', crop);

    const res = await fetch(`${API_BASE_URL}/scan/diagnose`, {
      method: 'POST',
      body: formData
    });
    return await res.json();
  }

  /**
   * 2. Send Chat Message to Agronomist AI
   * @param {string} message 
   * @param {string} preferredLanguage ('gu' | 'en')
   * @param {string} sessionId 
   */
  static async sendChatMessage(message, preferredLanguage = 'gu', sessionId = 'farmer_session_1') {
    const res = await fetch(`${API_BASE_URL}/chat/message`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ message, preferredLanguage, sessionId })
    });
    return await res.json();
  }

  /**
   * 3. Fetch Real-Time Field Weather & Advisory
   */
  static async getAgroWeather() {
    const res = await fetch(`${API_BASE_URL}/weather/advisory`);
    return await res.json();
  }

  /**
   * 4. Calculate Land Area and Seed Requirements
   */
  static async calculateLandDimensions(lengthFeet, widthFeet, cropKey = 'cotton') {
    const res = await fetch(`${API_BASE_URL}/land/calculate/dimensions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ lengthFeet, widthFeet, cropKey })
    });
    return await res.json();
  }

  static async calculateLandArea(areaValue, unit = 'vigha', cropKey = 'cotton') {
    const res = await fetch(`${API_BASE_URL}/land/calculate/area`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ areaValue, unit, cropKey })
    });
    return await res.json();
  }

  /**
   * 5. Crop Tracker Operations
   */
  static async getCrops() {
    const res = await fetch(`${API_BASE_URL}/crops`);
    return await res.json();
  }

  static async addCrop(cropData) {
    const res = await fetch(`${API_BASE_URL}/crops`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(cropData)
    });
    return await res.json();
  }

  static async deleteCrop(cropId) {
    const res = await fetch(`${API_BASE_URL}/crops/${cropId}`, {
      method: 'DELETE'
    });
    return await res.json();
  }
}

// Export for browser
window.KhedutApiClient = KhedutApiClient;
